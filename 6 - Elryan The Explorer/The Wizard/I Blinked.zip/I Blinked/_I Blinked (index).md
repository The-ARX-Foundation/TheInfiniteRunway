# Notes on Aeon The Awoken



# Post Timeline
Mirrored on [[ATA Post Timeline.canvas]]

Aeon The Awoken: After emoji speech [[Writing Log]]
Elryan The Explorer: Start up the elryan the explorer blog with some content rambling about uploading my consciousness to learn more about the human mind
Aeon The Awoken: [[0002_Awakening≈Echo]]


Elryan The Explorer: After noticing Aeon is out there [[Aeon Chat Activation Prompt (v0.1)]]